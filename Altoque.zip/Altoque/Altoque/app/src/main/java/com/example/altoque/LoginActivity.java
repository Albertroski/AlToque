package com.example.altoque;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUser, etPass;
    private Button btnLogin;
    private ProgressBar prog;
    private TextView tvError;

    private TextView tvRegisterUser;
    private TextView tvRegisterCompany;

    private AuthManager authManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        authManager = new AuthManager(this);
        if (authManager.isAuthenticated()) {
            startMainAndFinish();
            return;
        }

        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        btnLogin = findViewById(R.id.btnLogin);
        prog = findViewById(R.id.prog);
        tvError = findViewById(R.id.tvError);

        tvRegisterUser = findViewById(R.id.tvRegisterUser);
        tvRegisterCompany = findViewById(R.id.tvRegisterCompany);

        btnLogin.setOnClickListener(v -> attemptLogin());

        etPass.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER &&
                            event.getAction() == KeyEvent.ACTION_DOWN)) {
                attemptLogin();
                return true;
            }
            return false;
        });

        tvRegisterUser.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterUserActivity.class)));

        tvRegisterCompany.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterCompanyActivity.class)));
    }

    private void attemptLogin() {
        tvError.setText("");

        String user = etUser.getText() == null ? "" : etUser.getText().toString().trim();
        String pass = etPass.getText() == null ? "" : etPass.getText().toString().trim();

        if (user.isEmpty() || pass.isEmpty()) {
            tvError.setText("Introdueix usuari i contrasenya.");
            return;
        }

        setLoading(true);

        new Thread(() -> {

            ServerApi.LoginResult res = ServerApi.login(user, pass);

            runOnUiThread(() -> {
                setLoading(false);

                if (!res.ok) {
                    tvError.setText(res.missatge);
                    return;
                }

                if (res.token == null || res.token.trim().isEmpty()) {
                    tvError.setText("Error: el servidor no ha retornat token.");
                    return;
                }
                if (res.role == null) {
                    tvError.setText("Error: el servidor no ha retornat el rol.");
                    return;
                }

                String identifier = etUser.getText().toString().trim();

                String roleStr = String.valueOf(res.role);
                if ("USUARI".equalsIgnoreCase(roleStr)) roleStr = "CLIENT";
                if ("EMPRESA".equalsIgnoreCase(roleStr)) roleStr = "COMPANY";

                authManager.saveAuth(res.token, roleStr, identifier);

                startMainAndFinish();




                startMainAndFinish();
            });
        }).start();
    }

    private void setLoading(boolean loading) {
        prog.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
        etUser.setEnabled(!loading);
        etPass.setEnabled(!loading);
        tvRegisterUser.setEnabled(!loading);
        tvRegisterCompany.setEnabled(!loading);
    }

    private void startMainAndFinish() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}
