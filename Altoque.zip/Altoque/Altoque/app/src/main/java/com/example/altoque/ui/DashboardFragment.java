package com.example.altoque.ui;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.altoque.AuthManager;
import com.example.altoque.ServerApi;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class DashboardFragment extends Fragment {


    private TextInputEditText etNom, etDesc, etPreu;
    private MaterialButton btnAdd;
    private ProgressBar progress;


    private View menuView;
    private View addProductView;
    private View productsView;
    private View packsView;
    private View addPackView;
    private View editPackView;


    private LinearLayout productsContainer;
    private ProgressBar productsProgress;


    private LinearLayout packsContainer;
    private ProgressBar packsProgress;


    private TextInputEditText etPackNom, etPackDesc, etPackPreu;
    private MaterialButton btnCreatePack;
    private ProgressBar packProgress;
    private LinearLayout packProductsContainer;
    private final Set<String> selectedProductIdsForAdd = new HashSet<>();


    private long editingPackId = -1;
    private TextInputEditText etEditPackNom, etEditPackPreu;
    private MaterialButton btnSavePack;
    private ProgressBar editPackProgress;
    private LinearLayout editPackProductsContainer;
    private final Set<String> selectedProductIdsForEdit = new HashSet<>();

    public DashboardFragment() { super(); }

    @Nullable
    @Override
    public View onCreateView(@NonNull android.view.LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        ScrollView scroll = new ScrollView(requireContext());
        scroll.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(requireContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        root.setPadding(dp(16), dp(48), dp(16), dp(16));
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        scroll.addView(root);

        menuView = buildMenuView();
        addProductView = buildAddProductView();
        productsView = buildProductsView();
        packsView = buildPacksView();
        addPackView = buildAddPackView();
        editPackView = buildEditPackView();

        root.addView(menuView);
        root.addView(addProductView);
        root.addView(productsView);
        root.addView(packsView);
        root.addView(addPackView);
        root.addView(editPackView);

        showMenu();
        return scroll;
    }


    private View buildMenuView() {
        LinearLayout menu = new LinearLayout(requireContext());
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        menu.setGravity(Gravity.CENTER_HORIZONTAL);

        MaterialTextView title = new MaterialTextView(requireContext());
        title.setText("Dashboard empresa");
        title.setTextSize(20f);
        title.setTypeface(null, Typeface.BOLD);
        setBottomMargin(title, dp(12));
        menu.addView(title);

        MaterialCardView cardMyProducts = makeActionCard(
                "Veure els meus productes",
                "Consulta productes i elimina'ls si cal."
        );
        setBottomMargin(cardMyProducts, dp(12));
        cardMyProducts.setOnClickListener(v -> {
            showProducts();
            loadMyProducts();
        });

        MaterialCardView cardAddProduct = makeActionCard(
                "Afegir producte",
                "Crea un producte nou per vendre."
        );
        setBottomMargin(cardAddProduct, dp(12));
        cardAddProduct.setOnClickListener(v -> showAddProduct());

        MaterialCardView cardMyPacks = makeActionCard(
                "Veure els meus packs",
                "Consulta els packs creats per la teva empresa."
        );
        setBottomMargin(cardMyPacks, dp(12));
        cardMyPacks.setOnClickListener(v -> {
            showPacks();
            loadMyPacks();
        });

        MaterialCardView cardAddPack = makeActionCard(
                "Crear un pack nou",
                "Agrupa 2 o més productes en un pack."
        );
        setBottomMargin(cardAddPack, dp(12));
        cardAddPack.setOnClickListener(v -> {
            showAddPack();
            loadMyProductsForAddPack();
        });

        menu.addView(cardMyProducts);
        menu.addView(cardAddProduct);
        menu.addView(cardMyPacks);
        menu.addView(cardAddPack);

        return menu;
    }

    private MaterialCardView makeActionCard(String titleText, String subtitleText) {
        MaterialCardView card = new MaterialCardView(requireContext());
        card.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        card.setRadius(dp(18));
        card.setCardElevation(dp(2));
        card.setUseCompatPadding(true);
        card.setClickable(true);
        card.setFocusable(true);

        LinearLayout content = new LinearLayout(requireContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(16));

        MaterialTextView t = new MaterialTextView(requireContext());
        t.setText(titleText);
        t.setTextSize(18f);
        t.setTypeface(null, Typeface.BOLD);

        MaterialTextView s = new MaterialTextView(requireContext());
        s.setText(subtitleText);
        s.setTextSize(14f);

        content.addView(t);
        content.addView(space(dp(6)));
        content.addView(s);

        card.addView(content);
        return card;
    }


    private void showMenu() {
        menuView.setVisibility(View.VISIBLE);
        addProductView.setVisibility(View.GONE);
        productsView.setVisibility(View.GONE);
        packsView.setVisibility(View.GONE);
        addPackView.setVisibility(View.GONE);
        editPackView.setVisibility(View.GONE);
    }

    private void showAddProduct() {
        menuView.setVisibility(View.GONE);
        addProductView.setVisibility(View.VISIBLE);
        productsView.setVisibility(View.GONE);
        packsView.setVisibility(View.GONE);
        addPackView.setVisibility(View.GONE);
        editPackView.setVisibility(View.GONE);
    }

    private void showProducts() {
        menuView.setVisibility(View.GONE);
        addProductView.setVisibility(View.GONE);
        productsView.setVisibility(View.VISIBLE);
        packsView.setVisibility(View.GONE);
        addPackView.setVisibility(View.GONE);
        editPackView.setVisibility(View.GONE);
    }

    private void showPacks() {
        menuView.setVisibility(View.GONE);
        addProductView.setVisibility(View.GONE);
        productsView.setVisibility(View.GONE);
        packsView.setVisibility(View.VISIBLE);
        addPackView.setVisibility(View.GONE);
        editPackView.setVisibility(View.GONE);
    }

    private void showAddPack() {
        menuView.setVisibility(View.GONE);
        addProductView.setVisibility(View.GONE);
        productsView.setVisibility(View.GONE);
        packsView.setVisibility(View.GONE);
        addPackView.setVisibility(View.VISIBLE);
        editPackView.setVisibility(View.GONE);
    }

    private void showEditPack() {
        menuView.setVisibility(View.GONE);
        addProductView.setVisibility(View.GONE);
        productsView.setVisibility(View.GONE);
        packsView.setVisibility(View.GONE);
        addPackView.setVisibility(View.GONE);
        editPackView.setVisibility(View.VISIBLE);
    }


    private View buildProductsView() {
        LinearLayout wrapper = vWrap();
        wrapper.addView(backBtn(this::showMenu));

        MaterialTextView title = txtBold("Els meus productes", 18);
        setBottomMargin(title, dp(10));
        wrapper.addView(title);

        productsProgress = new ProgressBar(requireContext());
        setBottomMargin(productsProgress, dp(10));
        productsProgress.setVisibility(View.GONE);
        wrapper.addView(productsProgress);

        productsContainer = new LinearLayout(requireContext());
        productsContainer.setOrientation(LinearLayout.VERTICAL);
        productsContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        wrapper.addView(productsContainer);

        return wrapper;
    }

    private void loadMyProducts() {
        productsContainer.removeAllViews();
        productsProgress.setVisibility(View.VISIBLE);

        AuthManager am = new AuthManager(requireContext());
        String token = am.getToken();
        String cif = am.getIdentifier();

        new Thread(() -> {
            ServerApi.ProductListResult res = ServerApi.producteList(token, cif);

            requireActivity().runOnUiThread(() -> {
                productsProgress.setVisibility(View.GONE);

                if (!res.ok) { toast(res.missatge); return; }

                List<ServerApi.Producte> list = res.productes;
                if (list == null || list.isEmpty()) {
                    productsContainer.addView(txt("No tens productes encara.", 14));
                    return;
                }

                for (ServerApi.Producte p : list) productsContainer.addView(makeProductCard(p));
            });
        }).start();
    }

    private MaterialCardView makeProductCard(ServerApi.Producte p) {
        MaterialCardView card = cardBase();
        setBottomMargin(card, dp(12));

        LinearLayout content = vCol(dp(16), dp(16));

        content.addView(txtBold(p.nom, 16));
        content.addView(space(dp(6)));
        content.addView(txt(p.descripcio, 14));
        content.addView(space(dp(8)));
        content.addView(txt("Preu: " + p.preu + " €", 14));
        content.addView(space(dp(10)));

        LinearLayout bottomRow = new LinearLayout(requireContext());
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setGravity(Gravity.END);

        MaterialButton btnEdit = new MaterialButton(requireContext());
        btnEdit.setText("Editar");
        btnEdit.setAllCaps(false);
        btnEdit.setCornerRadius(dp(12));

        MaterialButton btnDelete = new MaterialButton(requireContext());
        btnDelete.setText("Eliminar");
        btnDelete.setAllCaps(false);
        btnDelete.setTextColor(0xFFFFFFFF);
        btnDelete.setBackgroundColor(0xFFD32F2F);
        btnDelete.setCornerRadius(dp(12));
        btnDelete.setPadding(dp(14), dp(8), dp(14), dp(8));

        LinearLayout.LayoutParams lpDel = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpDel.leftMargin = dp(10);
        btnDelete.setLayoutParams(lpDel);

        btnEdit.setOnClickListener(v -> showEditProductDialog(p));
        btnDelete.setOnClickListener(v -> deleteProduct(p, btnDelete));

        bottomRow.addView(btnEdit);
        bottomRow.addView(btnDelete);
        content.addView(bottomRow);


        card.addView(content);
        return card;
    }

    private void showEditProductDialog(ServerApi.Producte p) {
        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(10), dp(16), dp(2));

        TextInputLayout tilNom = new TextInputLayout(requireContext());
        tilNom.setHint("Nom");
        TextInputEditText etNom = new TextInputEditText(requireContext());
        etNom.setText(p.nom);
        tilNom.addView(etNom);

        TextInputLayout tilDesc = new TextInputLayout(requireContext());
        tilDesc.setHint("Descripció");
        TextInputEditText etDesc = new TextInputEditText(requireContext());
        etDesc.setText(p.descripcio);
        tilDesc.addView(etDesc);

        TextInputLayout tilPreu = new TextInputLayout(requireContext());
        tilPreu.setHint("Preu (€) (ex: 2.30)");
        TextInputEditText etPreu = new TextInputEditText(requireContext());
        etPreu.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);


        String preuTxt = String.format(java.util.Locale.getDefault(), "%.2f", p.preu);
        preuTxt = preuTxt.replace(",", "."); // per evitar decimals amb coma
        etPreu.setText(preuTxt);
        tilPreu.addView(etPreu);

        ProgressBar pb = new ProgressBar(requireContext());
        pb.setVisibility(View.GONE);

        box.addView(tilNom);
        box.addView(space(dp(10)));
        box.addView(tilDesc);
        box.addView(space(dp(10)));
        box.addView(tilPreu);
        box.addView(space(dp(10)));
        box.addView(pb);


        final androidx.appcompat.app.AlertDialog dlg =
                new com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Editar producte")
                        .setView(box)
                        .setNegativeButton("Cancel·lar", null)
                        .setPositiveButton("Guardar", null)
                        .create();

        dlg.show();

        dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String nom = etNom.getText() == null ? "" : etNom.getText().toString().trim();
            String desc = etDesc.getText() == null ? "" : etDesc.getText().toString().trim();
            String preuStr = etPreu.getText() == null ? "" : etPreu.getText().toString().trim().replace(",", ".");

            tilNom.setError(null);
            tilDesc.setError(null);
            tilPreu.setError(null);

            if (nom.isEmpty()) { tilNom.setError("Obligatori"); return; }
            if (desc.isEmpty()) { tilDesc.setError("Obligatori"); return; }
            if (preuStr.isEmpty()) { tilPreu.setError("Obligatori"); return; }

            double preu;
            try {
                preu = Double.parseDouble(preuStr);
            } catch (Exception e) {
                tilPreu.setError("Preu invàlid");
                return;
            }

            long id = parseLongSafe(p.id);
            if (id <= 0) {
                toast("Id de producte invàlid");
                return;
            }

            pb.setVisibility(View.VISIBLE);
            dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setEnabled(false);

            String token = new AuthManager(requireContext()).getToken();

            new Thread(() -> {
                ServerApi.SimpleResult res = ServerApi.producteMod(token, id, nom, desc, preu);

                requireActivity().runOnUiThread(() -> {
                    pb.setVisibility(View.GONE);
                    dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                    dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setEnabled(true);

                    toast(res.missatge);

                    if (res.ok) {
                        dlg.dismiss();
                        loadMyProducts();
                    }
                });
            }).start();
        });
    }



    private void deleteProduct(ServerApi.Producte p, MaterialButton btnDelete) {
        btnDelete.setEnabled(false);
        String oldText = btnDelete.getText().toString();
        btnDelete.setText("Eliminant...");

        String token = new AuthManager(requireContext()).getToken();
        String id = p.id;

        new Thread(() -> {
            ServerApi.SimpleResult res = ServerApi.producteDel(token, id);

            requireActivity().runOnUiThread(() -> {
                if (!res.ok) {
                    btnDelete.setEnabled(true);
                    btnDelete.setText(oldText);
                    toast(res.missatge);
                    return;
                }
                toast("Producte eliminat");
                loadMyProducts();
            });
        }).start();
    }

    private View buildAddProductView() {
        LinearLayout wrapper = vWrap();
        wrapper.addView(backBtn(this::showMenu));

        MaterialCardView card = cardBase();
        LinearLayout content = vCol(dp(16), dp(16));

        TextInputLayout tilNom = new TextInputLayout(requireContext());
        tilNom.setHint("Nom del producte");
        etNom = new TextInputEditText(requireContext());
        tilNom.addView(etNom);

        TextInputLayout tilDesc = new TextInputLayout(requireContext());
        tilDesc.setHint("Descripció");
        etDesc = new TextInputEditText(requireContext());
        tilDesc.addView(etDesc);

        TextInputLayout tilPreu = new TextInputLayout(requireContext());
        tilPreu.setHint("Preu (ex: 9.50)");
        etPreu = new TextInputEditText(requireContext());
        etPreu.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        tilPreu.addView(etPreu);

        btnAdd = new MaterialButton(requireContext());
        btnAdd.setText("Afegir producte");
        btnAdd.setAllCaps(false);

        progress = new ProgressBar(requireContext());
        progress.setVisibility(View.GONE);

        content.addView(tilNom);
        content.addView(space(dp(10)));
        content.addView(tilDesc);
        content.addView(space(dp(10)));
        content.addView(tilPreu);
        content.addView(space(dp(14)));
        content.addView(btnAdd);
        content.addView(space(dp(10)));
        content.addView(progress);

        card.addView(content);
        wrapper.addView(card);

        btnAdd.setOnClickListener(v -> addProduct());
        return wrapper;
    }

    private void addProduct() {
        String nom = safeText(etNom);
        String desc = safeText(etDesc);
        String preu = safeText(etPreu);

        boolean hasError = false;
        if (nom.isEmpty()) { etNom.setError("Obligatori"); hasError = true; }
        if (desc.isEmpty()) { etDesc.setError("Obligatori"); hasError = true; }
        if (preu.isEmpty()) { etPreu.setError("Obligatori"); hasError = true; }
        if (hasError) return;

        setAddProductLoading(true);

        String token = new AuthManager(requireContext()).getToken();

        new Thread(() -> {
            ServerApi.SimpleResult res = ServerApi.producteAdd(token, nom, desc, preu);

            requireActivity().runOnUiThread(() -> {
                setAddProductLoading(false);
                toast(res.missatge);
                if (res.ok) { etNom.setText(""); etDesc.setText(""); etPreu.setText(""); }
            });
        }).start();
    }

    private void setAddProductLoading(boolean loading) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnAdd.setEnabled(!loading);
        etNom.setEnabled(!loading);
        etDesc.setEnabled(!loading);
        etPreu.setEnabled(!loading);
    }

    private View buildPacksView() {
        LinearLayout wrapper = vWrap();
        wrapper.addView(backBtn(this::showMenu));

        MaterialTextView title = txtBold("Els meus packs", 18);
        setBottomMargin(title, dp(10));
        wrapper.addView(title);

        packsProgress = new ProgressBar(requireContext());
        setBottomMargin(packsProgress, dp(10));
        packsProgress.setVisibility(View.GONE);
        wrapper.addView(packsProgress);

        packsContainer = new LinearLayout(requireContext());
        packsContainer.setOrientation(LinearLayout.VERTICAL);
        packsContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        wrapper.addView(packsContainer);

        return wrapper;
    }

    private void loadMyPacks() {
        packsContainer.removeAllViews();
        packsProgress.setVisibility(View.VISIBLE);

        AuthManager am = new AuthManager(requireContext());
        String token = am.getToken();
        String cif = am.getIdentifier();

        new Thread(() -> {
            ServerApi.PackListResult res = ServerApi.packList(token, cif);

            requireActivity().runOnUiThread(() -> {
                packsProgress.setVisibility(View.GONE);

                if (!res.ok) { toast(res.missatge); return; }

                List<ServerApi.Pack> list = res.packs;
                if (list == null || list.isEmpty()) {
                    packsContainer.addView(txt("No tens packs encara.", 14));
                    return;
                }

                for (ServerApi.Pack p : list) packsContainer.addView(makePackCard(p));
            });
        }).start();
    }

    private View makePackCard(ServerApi.Pack p) {
        MaterialCardView card = new MaterialCardView(requireContext());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        card.setRadius(dp(16));
        card.setCardElevation(dp(1));
        card.setUseCompatPadding(true);

        LinearLayout content = new LinearLayout(requireContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(14));

        MaterialTextView tvNom = new MaterialTextView(requireContext());
        tvNom.setText(p.nom);
        tvNom.setTextSize(16f);
        tvNom.setTypeface(null, android.graphics.Typeface.BOLD);

        MaterialTextView tvDesc = new MaterialTextView(requireContext());
        tvDesc.setText(p.descripcio == null ? "" : p.descripcio);
        tvDesc.setTextSize(14f);

        MaterialTextView tvInfo = new MaterialTextView(requireContext());
        double euros = p.preu / 100.0; // si p.preu ve en cèntims
        String itemsTxt = (p.numItems > 0) ? (" · " + p.numItems + " productes") : "";
        tvInfo.setText(String.format(java.util.Locale.getDefault(), "Preu: %.2f €%s", euros, itemsTxt));
        tvInfo.setTextSize(14f);

        content.addView(tvNom);
        content.addView(space(dp(6)));
        if (p.descripcio != null && !p.descripcio.trim().isEmpty()) {
            content.addView(tvDesc);
            content.addView(space(dp(8)));
        }
        content.addView(tvInfo);
        content.addView(space(dp(12)));


        LinearLayout row = new LinearLayout(requireContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END);

        MaterialButton btnDetalls = new MaterialButton(requireContext());
        btnDetalls.setText("Detalls");
        btnDetalls.setAllCaps(false);
        btnDetalls.setCornerRadius(dp(12));
        btnDetalls.setOnClickListener(v -> {
            long id = parseLongSafe(p.id);
            if (id <= 0) { toast("Id pack invàlid"); return; }
            showPackDetailDialogEmpresa(id); // PACK_GET (empresa)
        });

        MaterialButton btnEdit = new MaterialButton(requireContext());
        btnEdit.setText("Editar");
        btnEdit.setAllCaps(false);
        btnEdit.setCornerRadius(dp(12));
        btnEdit.setOnClickListener(v -> {
            long id = parseLongSafe(p.id);
            if (id <= 0) { toast("Id pack invàlid"); return; }

            showEditPack();
            openEditPack(id);
        });

        MaterialButton btnDel = new MaterialButton(requireContext());
        btnDel.setText("Eliminar");
        btnDel.setAllCaps(false);
        btnDel.setCornerRadius(dp(12));
        btnDel.setTextColor(0xFFFFFFFF);
        btnDel.setBackgroundColor(0xFFD32F2F);
        btnDel.setOnClickListener(v -> {
            long id = parseLongSafe(p.id);
            if (id <= 0) { toast("Id pack invàlid"); return; }
            deletePack(id, btnDel);
        });


        LinearLayout.LayoutParams lpEdit = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpEdit.leftMargin = dp(10);
        btnEdit.setLayoutParams(lpEdit);

        LinearLayout.LayoutParams lpDel = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lpDel.leftMargin = dp(10);
        btnDel.setLayoutParams(lpDel);

        row.addView(btnDetalls);
        row.addView(btnEdit);
        row.addView(btnDel);

        content.addView(row);
        card.addView(content);

        return card;
    }


    private void showPackDetailDialogEmpresa(long packId) {
        String token = new AuthManager(requireContext()).getToken();

        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(10), dp(16), dp(6));

        ProgressBar pb = new ProgressBar(requireContext());
        box.addView(pb);

        final androidx.appcompat.app.AlertDialog dlg =
                new com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Detall del pack")
                        .setView(box)
                        .setPositiveButton("Tancar", null)
                        .create();

        dlg.show();

        new Thread(() -> {
            ServerApi.PackGetResult res = ServerApi.packGet(token, packId); // ✅ sessió empresa

            requireActivity().runOnUiThread(() -> {
                box.removeAllViews();

                if (!res.ok || res.pack == null) {
                    MaterialTextView err = new MaterialTextView(requireContext());
                    err.setText("Error: " + res.missatge);
                    box.addView(err);
                    return;
                }


                MaterialTextView tvNom = new MaterialTextView(requireContext());
                tvNom.setText(res.pack.nom);
                tvNom.setTextSize(18f);
                tvNom.setTypeface(null, android.graphics.Typeface.BOLD);

                double euros = res.pack.preu / 100.0;
                MaterialTextView tvPreu = new MaterialTextView(requireContext());
                tvPreu.setText(String.format(java.util.Locale.getDefault(), "Preu: %.2f €", euros));
                tvPreu.setPadding(0, dp(6), 0, dp(10));

                box.addView(tvNom);
                box.addView(tvPreu);


                java.util.List<ServerApi.PackItem> items = res.pack.items; // depèn del teu model (mira nota sota)
                if (items == null || items.isEmpty()) {
                    MaterialTextView empty = new MaterialTextView(requireContext());
                    empty.setText("Aquest pack no té items.");
                    box.addView(empty);
                    return;
                }

                MaterialTextView hdr = new MaterialTextView(requireContext());
                hdr.setText("Items:");
                hdr.setTypeface(null, android.graphics.Typeface.BOLD);
                hdr.setPadding(0, dp(6), 0, dp(6));
                box.addView(hdr);

                for (ServerApi.PackItem it : items) {
                    MaterialTextView line = new MaterialTextView(requireContext());
                    line.setText("• Producte #" + it.producteId + " × " + it.quantitat);
                    box.addView(line);
                }
            });
        }).start();
    }



    private View buildAddPackView() {
        LinearLayout wrapper = vWrap();
        wrapper.addView(backBtn(this::showMenu));

        MaterialTextView title = txtBold("Crear un pack nou", 18);
        setBottomMargin(title, dp(10));
        wrapper.addView(title);

        MaterialCardView card = cardBase();
        LinearLayout content = vCol(dp(16), dp(16));

        TextInputLayout tilNom = new TextInputLayout(requireContext());
        tilNom.setHint("Nom del pack");
        etPackNom = new TextInputEditText(requireContext());
        tilNom.addView(etPackNom);

        TextInputLayout tilDesc = new TextInputLayout(requireContext());
        tilDesc.setHint("Descripció (opcional)");
        etPackDesc = new TextInputEditText(requireContext());
        tilDesc.addView(etPackDesc);

        TextInputLayout tilPreu = new TextInputLayout(requireContext());
        tilPreu.setHint("Preu (€) (ex: 19.99)");
        etPackPreu = new TextInputEditText(requireContext());
        etPackPreu.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        tilPreu.addView(etPackPreu);

        MaterialTextView subtitle = txt("Selecciona 2 o més productes:", 14);
        setBottomMargin(subtitle, dp(6));

        packProductsContainer = new LinearLayout(requireContext());
        packProductsContainer.setOrientation(LinearLayout.VERTICAL);

        btnCreatePack = new MaterialButton(requireContext());
        btnCreatePack.setText("Crear pack");
        btnCreatePack.setAllCaps(false);

        packProgress = new ProgressBar(requireContext());
        packProgress.setVisibility(View.GONE);

        content.addView(tilNom);
        content.addView(space(dp(10)));
        content.addView(tilDesc);
        content.addView(space(dp(10)));
        content.addView(tilPreu);
        content.addView(space(dp(14)));
        content.addView(subtitle);
        content.addView(packProductsContainer);
        content.addView(space(dp(14)));
        content.addView(btnCreatePack);
        content.addView(space(dp(10)));
        content.addView(packProgress);

        card.addView(content);
        wrapper.addView(card);

        btnCreatePack.setOnClickListener(v -> createPack());
        return wrapper;
    }

    private void loadMyProductsForAddPack() {
        packProductsContainer.removeAllViews();
        selectedProductIdsForAdd.clear();
        packProgress.setVisibility(View.VISIBLE);

        AuthManager am = new AuthManager(requireContext());
        String token = am.getToken();
        String cif = am.getIdentifier();

        new Thread(() -> {
            ServerApi.ProductListResult res = ServerApi.producteList(token, cif);

            requireActivity().runOnUiThread(() -> {
                packProgress.setVisibility(View.GONE);

                if (!res.ok) { toast(res.missatge); return; }

                List<ServerApi.Producte> list = res.productes;
                if (list == null || list.isEmpty()) {
                    packProductsContainer.addView(txt("No tens productes. Crea'n almenys 2 per poder fer un pack.", 14));
                    return;
                }

                for (ServerApi.Producte p : list) packProductsContainer.addView(makeSelectableRowForAdd(p));
            });
        }).start();
    }

    private View makeSelectableRowForAdd(ServerApi.Producte p) {
        final String pid = p.id;

        MaterialCheckBox cb = new MaterialCheckBox(requireContext());
        cb.setText(p.nom + " · " + p.preu + " €");
        cb.setChecked(false);

        cb.setOnCheckedChangeListener((b, checked) -> {
            if (pid == null || pid.isEmpty()) return;
            if (checked) selectedProductIdsForAdd.add(pid);
            else selectedProductIdsForAdd.remove(pid);
        });

        LinearLayout row = new LinearLayout(requireContext());
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(4), 0, dp(4));
        row.addView(cb);
        return row;
    }

    private void createPack() {
        String nom = safeText(etPackNom);
        String preuTxt = safeText(etPackPreu).replace(",", ".");

        if (nom.isEmpty()) { etPackNom.setError("Obligatori"); return; }
        if (preuTxt.isEmpty()) { etPackPreu.setError("Obligatori"); return; }
        if (selectedProductIdsForAdd.size() < 2) { toast("Has de seleccionar com a mínim 2 productes."); return; }

        long preuCents;
        try {
            double euros = Double.parseDouble(preuTxt);
            preuCents = Math.round(euros * 100.0);
        } catch (Exception e) {
            etPackPreu.setError("Preu invàlid");
            return;
        }

        setAddPackLoading(true);

        String token = new AuthManager(requireContext()).getToken();
        List<String> ids = new ArrayList<>(selectedProductIdsForAdd);

        new Thread(() -> {
            ServerApi.SimpleResult res = ServerApi.packAdd(token, nom, preuCents, ids);

            requireActivity().runOnUiThread(() -> {
                setAddPackLoading(false);
                toast(res.missatge);
                if (res.ok) {
                    etPackNom.setText("");
                    etPackDesc.setText("");
                    etPackPreu.setText("");
                    selectedProductIdsForAdd.clear();
                    loadMyProductsForAddPack();
                }
            });
        }).start();
    }

    private void setAddPackLoading(boolean loading) {
        packProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnCreatePack.setEnabled(!loading);
        etPackNom.setEnabled(!loading);
        etPackDesc.setEnabled(!loading);
        etPackPreu.setEnabled(!loading);
    }

    private void deletePack(long packId, MaterialButton btnDel) {
        btnDel.setEnabled(false);
        String old = btnDel.getText().toString();
        btnDel.setText("Eliminant...");

        String token = new AuthManager(requireContext()).getToken();

        new Thread(() -> {
            ServerApi.SimpleResult res = ServerApi.packDel(token, packId);

            requireActivity().runOnUiThread(() -> {
                if (!res.ok) {
                    btnDel.setEnabled(true);
                    btnDel.setText(old);
                    toast(res.missatge);
                    return;
                }
                toast("Pack eliminat");
                loadMyPacks(); // refresca llista
            });
        }).start();
    }

    private View buildEditPackView() {
        LinearLayout wrapper = vWrap();
        wrapper.addView(backBtn(() -> {
            showPacks();
            loadMyPacks();
        }));

        MaterialTextView title = txtBold("Editar pack", 18);
        setBottomMargin(title, dp(10));
        wrapper.addView(title);

        MaterialCardView card = cardBase();
        LinearLayout content = vCol(dp(16), dp(16));

        TextInputLayout tilNom = new TextInputLayout(requireContext());
        tilNom.setHint("Nom del pack");
        etEditPackNom = new TextInputEditText(requireContext());
        tilNom.addView(etEditPackNom);

        TextInputLayout tilPreu = new TextInputLayout(requireContext());
        tilPreu.setHint("Preu (€)");
        etEditPackPreu = new TextInputEditText(requireContext());
        etEditPackPreu.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        tilPreu.addView(etEditPackPreu);

        MaterialTextView subtitle = txt("Productes del pack (marca/desmarca):", 14);
        setBottomMargin(subtitle, dp(6));

        editPackProductsContainer = new LinearLayout(requireContext());
        editPackProductsContainer.setOrientation(LinearLayout.VERTICAL);

        btnSavePack = new MaterialButton(requireContext());
        btnSavePack.setText("Guardar canvis");
        btnSavePack.setAllCaps(false);

        editPackProgress = new ProgressBar(requireContext());
        editPackProgress.setVisibility(View.GONE);

        content.addView(tilNom);
        content.addView(space(dp(10)));
        content.addView(tilPreu);
        content.addView(space(dp(14)));
        content.addView(subtitle);
        content.addView(editPackProductsContainer);
        content.addView(space(dp(14)));
        content.addView(btnSavePack);
        content.addView(space(dp(10)));
        content.addView(editPackProgress);

        card.addView(content);
        wrapper.addView(card);

        btnSavePack.setOnClickListener(v -> saveEditedPack());
        return wrapper;
    }

    private void openEditPack(long packId) {
        editingPackId = packId;
        selectedProductIdsForEdit.clear();
        editPackProductsContainer.removeAllViews();
        setEditPackLoading(true);

        AuthManager am = new AuthManager(requireContext());
        String token = am.getToken();
        String cif = am.getIdentifier();

        new Thread(() -> {
            ServerApi.PackGetResult packRes = ServerApi.packGet(token, packId);

            requireActivity().runOnUiThread(() -> {
                if (!packRes.ok || packRes.pack == null) {
                    setEditPackLoading(false);
                    toast(packRes.missatge);
                    return;
                }

                etEditPackNom.setText(packRes.pack.nom);

                double euros = packRes.pack.preu / 100.0;
                etEditPackPreu.setText(String.format(Locale.getDefault(), "%.2f", euros));

                selectedProductIdsForEdit.clear();

                if (packRes.pack.producteIds != null) {
                    for (String pid : packRes.pack.producteIds) {
                        if (pid != null && !pid.isEmpty()) {
                            selectedProductIdsForEdit.add(pid);
                        }
                    }
                }


                loadMyProductsForEditPack(cif, token);
            });
        }).start();
    }

    private void loadMyProductsForEditPack(String cif, String token) {
        editPackProductsContainer.removeAllViews();

        new Thread(() -> {
            ServerApi.ProductListResult prodRes = ServerApi.producteList(token, cif);

            requireActivity().runOnUiThread(() -> {
                setEditPackLoading(false);

                if (!prodRes.ok) { toast(prodRes.missatge); return; }

                List<ServerApi.Producte> list = prodRes.productes;
                if (list == null || list.isEmpty()) {
                    editPackProductsContainer.addView(txt("No tens productes per editar aquest pack.", 14));
                    return;
                }

                for (ServerApi.Producte p : list) {
                    final String pid = p.id;
                    if (pid == null || pid.isEmpty()) continue;

                    MaterialCheckBox cb = new MaterialCheckBox(requireContext());
                    cb.setText(p.nom + " · " + p.preu + " €");
                    cb.setChecked(selectedProductIdsForEdit.contains(pid));

                    cb.setOnCheckedChangeListener((b, checked) -> {
                        if (checked) selectedProductIdsForEdit.add(pid);
                        else selectedProductIdsForEdit.remove(pid);
                    });

                    LinearLayout row = new LinearLayout(requireContext());
                    row.setOrientation(LinearLayout.VERTICAL);
                    row.setPadding(0, dp(4), 0, dp(4));
                    row.addView(cb);

                    editPackProductsContainer.addView(row);
                }
            });
        }).start();
    }

    private void saveEditedPack() {
        String nom = safeText(etEditPackNom);
        String preuTxt = safeText(etEditPackPreu).replace(",", ".");

        if (editingPackId <= 0) { toast("Pack invàlid"); return; }
        if (nom.isEmpty()) { etEditPackNom.setError("Obligatori"); return; }
        if (preuTxt.isEmpty()) { etEditPackPreu.setError("Obligatori"); return; }
        if (selectedProductIdsForEdit.size() < 2) { toast("El pack ha de tenir mínim 2 productes."); return; }

        long preuCents;
        try {
            double euros = Double.parseDouble(preuTxt);
            preuCents = Math.round(euros * 100.0);
        } catch (Exception e) {
            etEditPackPreu.setError("Preu invàlid");
            return;
        }

        setEditPackLoading(true);

        String token = new AuthManager(requireContext()).getToken();
        List<String> ids = new ArrayList<>(selectedProductIdsForEdit);

        long packId = editingPackId;
        String nomFinal = nom;
        long preuFinal = preuCents;

        new Thread(() -> {
            ServerApi.SimpleResult res = ServerApi.packMod(token, packId, nomFinal, preuFinal, ids);

            requireActivity().runOnUiThread(() -> {
                setEditPackLoading(false);
                toast(res.missatge);
                if (res.ok) {
                    showPacks();
                    loadMyPacks();
                }
            });
        }).start();
    }

    private void setEditPackLoading(boolean loading) {
        editPackProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnSavePack.setEnabled(!loading);
        etEditPackNom.setEnabled(!loading);
        etEditPackPreu.setEnabled(!loading);
    }


    private MaterialButton backBtn(Runnable onClick) {
        MaterialButton b = new MaterialButton(requireContext());
        b.setText("← Tornar");
        b.setAllCaps(false);
        setBottomMargin(b, dp(10));
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    private LinearLayout vWrap() {
        LinearLayout w = new LinearLayout(requireContext());
        w.setOrientation(LinearLayout.VERTICAL);
        w.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        w.setGravity(Gravity.CENTER_HORIZONTAL);
        return w;
    }

    private MaterialCardView cardBase() {
        MaterialCardView card = new MaterialCardView(requireContext());
        card.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        card.setRadius(dp(18));
        card.setCardElevation(dp(2));
        card.setUseCompatPadding(true);
        return card;
    }

    private LinearLayout vCol(int padX, int padY) {
        LinearLayout c = new LinearLayout(requireContext());
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(padX, padY, padX, padY);
        return c;
    }

    private MaterialTextView txt(String s, int size) {
        MaterialTextView t = new MaterialTextView(requireContext());
        t.setText(s);
        t.setTextSize(size);
        return t;
    }

    private MaterialTextView txtBold(String s, int size) {
        MaterialTextView t = txt(s, size);
        t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private void toast(String s) {
        Toast.makeText(requireContext(), s, Toast.LENGTH_LONG).show();
    }

    private String safeText(TextInputEditText et) {
        return et != null && et.getText() != null ? et.getText().toString().trim() : "";
    }

    private long parseLongSafe(String s) {
        try { return Long.parseLong(s); } catch (Exception e) { return -1; }
    }

    private View space(int h) {
        View v = new View(requireContext());
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, h
        ));
        return v;
    }

    private void setBottomMargin(View v, int margin) {
        ViewGroup.LayoutParams base = v.getLayoutParams();
        LinearLayout.LayoutParams lp;
        if (base instanceof LinearLayout.LayoutParams) lp = (LinearLayout.LayoutParams) base;
        else lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = margin;
        v.setLayoutParams(lp);
    }

    private int dp(int v) {
        float d = requireContext().getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }
}
