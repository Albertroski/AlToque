package com.example.altoque.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.altoque.AuthManager;
import com.example.altoque.LoginActivity;
import com.example.altoque.R;
import com.example.altoque.ServerApi;

public class ProfileFragment extends Fragment {

    private TextView tvUsuari;
    private EditText etNom, etCognoms, etNomEmpresa, etPassword;
    private Button btnSave, btnLogout, btnDelete;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        tvUsuari = view.findViewById(R.id.tvUsuari);
        etNom = view.findViewById(R.id.etNom);
        etCognoms = view.findViewById(R.id.etCognoms);
        etNomEmpresa = view.findViewById(R.id.etNomEmpresa);
        etPassword = view.findViewById(R.id.etPassword);

        btnSave = view.findViewById(R.id.btnSave);
        btnLogout = view.findViewById(R.id.btnLogout);
        btnDelete = view.findViewById(R.id.btnDeleteAccount);

        fillProfileAndRoleUI();

        btnSave.setOnClickListener(v -> saveChanges());
        btnLogout.setOnClickListener(v -> logout());
        btnDelete.setOnClickListener(v -> confirmDelete());

        return view;
    }

    private void fillProfileAndRoleUI() {
        AuthManager auth = new AuthManager(requireContext());

        String identifier = auth.getIdentifier();
        tvUsuari.setText(identifier != null ? identifier : "-");

        AuthManager.Role role = auth.getRole();

        if (role == AuthManager.Role.COMPANY) {
            etNom.setVisibility(View.GONE);
            etCognoms.setVisibility(View.GONE);
            etNomEmpresa.setVisibility(View.VISIBLE);
        } else {
            etNom.setVisibility(View.VISIBLE);
            etCognoms.setVisibility(View.VISIBLE);
            etNomEmpresa.setVisibility(View.GONE);
        }
    }

    private void saveChanges() {
        AuthManager auth = new AuthManager(requireContext());
        String token = auth.getToken();
        AuthManager.Role role = auth.getRole();
        final String tokenFinal = auth.getToken();
        final String identifierFinal = auth.getIdentifier(); // ✅ email o CIF
        final AuthManager.Role roleFinal = auth.getRole();
        String rawPass = safe(etPassword);
        String rawNom = safe(etNom);
        String rawCognoms = safe(etCognoms);
        String rawNomEmpresa = safe(etNomEmpresa);

        final String passFinal = rawPass.isEmpty() ? "" : rawPass;
        final String nomFinal = rawNom;
        final String cognomsFinal = rawCognoms;
        final String nomEmpresaFinal = rawNomEmpresa;


        setButtonsEnabled(false);

        new Thread(() -> {
            ServerApi.SimpleResult res;

            if (roleFinal == AuthManager.Role.COMPANY) {
                res = ServerApi.empresaMod(tokenFinal, identifierFinal, passFinal, nomEmpresaFinal);
            } else {
                res = ServerApi.usuariMod(tokenFinal, identifierFinal, passFinal, nomFinal, cognomsFinal);
            }

            requireActivity().runOnUiThread(() -> {
                setButtonsEnabled(true);
                Toast.makeText(requireContext(), res.missatge, Toast.LENGTH_LONG).show();

                if (res.ok) {
                    etPassword.setText("");
                }
            });
        }).start();
    }


    private void confirmDelete() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Eliminar compte")
                .setMessage("Aquesta acció és permanent. Segur que vols eliminar el compte?")
                .setPositiveButton("Eliminar", (d, w) -> deleteAccount())
                .setNegativeButton("Cancel·lar", null)
                .show();
    }

    private void deleteAccount() {
        AuthManager auth = new AuthManager(requireContext());
        String token = auth.getToken();
        AuthManager.Role role = auth.getRole();

        setButtonsEnabled(false);

        new Thread(() -> {
            ServerApi.SimpleResult res =
                    (role == AuthManager.Role.COMPANY)
                            ? ServerApi.empresaDel(token)
                            : ServerApi.usuariDel(token);

            requireActivity().runOnUiThread(() -> {
                setButtonsEnabled(true);

                if (!res.ok) {
                    Toast.makeText(requireContext(), res.missatge, Toast.LENGTH_LONG).show();
                    return;
                }

                Toast.makeText(requireContext(), "Compte eliminat", Toast.LENGTH_SHORT).show();

                auth.clear();
                Intent i = new Intent(requireContext(), LoginActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                requireActivity().finish();
            });
        }).start();
    }

    private void logout() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Tancar sessió")
                .setMessage("Segur que vols tancar la sessió?")
                .setPositiveButton("Sí", (d, w) -> {
                    AuthManager auth = new AuthManager(requireContext());
                    auth.clear();
                    Intent i = new Intent(requireContext(), LoginActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    requireActivity().finish();
                })
                .setNegativeButton("Cancel·lar", null)
                .show();
    }

    private void setButtonsEnabled(boolean enabled) {
        btnSave.setEnabled(enabled);
        btnLogout.setEnabled(enabled);
        btnDelete.setEnabled(enabled);
    }

    private String safe(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
