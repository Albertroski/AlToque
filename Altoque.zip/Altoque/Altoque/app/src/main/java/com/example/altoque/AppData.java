package com.example.altoque;

import java.util.ArrayList;
import java.util.List;

public class AppData {
    private static List<EmpresaInfo> empreses = new ArrayList<>();

    public static void setEmpreses(List<EmpresaInfo> llista) {
        empreses = (llista == null) ? new ArrayList<>() : llista;
    }

    public static List<EmpresaInfo> getEmpreses() {
        return empreses;
    }
}
