package com.example.altoque.ui;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import android.view.Gravity;

public class SearchFragment extends Fragment {
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle b) {
        TextView tv = new TextView(requireContext()); tv.setText("Cerca"); tv.setGravity(Gravity.CENTER); return tv;
    }
}
