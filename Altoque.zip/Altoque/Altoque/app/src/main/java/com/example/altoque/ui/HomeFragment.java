package com.example.altoque.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.altoque.AppData;
import com.example.altoque.AuthManager;
import com.example.altoque.EmpresaInfo;
import com.example.altoque.R;
import com.example.altoque.ServerApi;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class HomeFragment extends Fragment {

    private TextView tvStatus;
    private LinearLayout listContainer;
    private ProgressBar progress;

    public HomeFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull android.view.LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {


        FrameLayout root = new FrameLayout(requireContext());
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        root.setPadding(dp(12), dp(12), dp(12), dp(12));


        MaterialCardView bigCard = new MaterialCardView(requireContext());
        bigCard.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        bigCard.setRadius(dp(20));
        bigCard.setCardElevation(dp(2)); // més subtil
        bigCard.setUseCompatPadding(true);
        bigCard.setCardBackgroundColor(getColor(R.color.card_bg));


        LinearLayout bigContent = new LinearLayout(requireContext());
        bigContent.setOrientation(LinearLayout.VERTICAL);
        bigContent.setPadding(dp(16), dp(16), dp(16), dp(16));
        bigContent.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));


        tvStatus = new TextView(requireContext());
        tvStatus.setText("");
        tvStatus.setTextColor(getColor(R.color.text_secondary));
        tvStatus.setPadding(0, 0, 0, dp(8));


        progress = new ProgressBar(requireContext());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        p.gravity = Gravity.START;
        progress.setLayoutParams(p);
        progress.setVisibility(View.GONE);


        ScrollView scroll = new ScrollView(requireContext());
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        );
        scroll.setLayoutParams(scrollLp);

        listContainer = new LinearLayout(requireContext());
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        scroll.addView(listContainer);

        bigContent.addView(tvStatus);
        bigContent.addView(progress);
        bigContent.addView(scroll);
        bigCard.addView(bigContent);
        root.addView(bigCard);

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<EmpresaInfo> cached = AppData.getEmpreses();
        if (cached != null && !cached.isEmpty()) {
            renderCards(cached);
            return;
        }

        fetchEmpreses();
    }

    private void fetchEmpreses() {
        progress.setVisibility(View.VISIBLE);
        tvStatus.setText("Carregant...");

        String token = new AuthManager(requireContext()).getToken();

        new Thread(() -> {
            ServerApi.EmpresaListResult res = ServerApi.empresaList(token);

            requireActivity().runOnUiThread(() -> {
                progress.setVisibility(View.GONE);

                if (!res.ok) {
                    tvStatus.setText(res.missatge);
                    return;
                }

                tvStatus.setText("");
                AppData.setEmpreses(res.empreses);
                renderCards(res.empreses);
            });
        }).start();
    }

    private void renderCards(List<EmpresaInfo> empreses) {
        listContainer.removeAllViews();

        if (empreses == null || empreses.isEmpty()) {
            TextView empty = new TextView(requireContext());
            empty.setText("No hi ha empreses disponibles.");
            empty.setTextColor(getColor(R.color.text_secondary));
            listContainer.addView(empty);
            return;
        }

        for (EmpresaInfo e : empreses) {
            listContainer.addView(createEmpresaCard(e));
        }
    }

    private View createEmpresaCard(EmpresaInfo empresa) {
        MaterialCardView card = new MaterialCardView(requireContext());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);

        card.setRadius(dp(16));
        card.setCardElevation(dp(1));
        card.setUseCompatPadding(true);

        LinearLayout content = new LinearLayout(requireContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView tvNom = new TextView(requireContext());
        tvNom.setText(empresa.nom);
        tvNom.setTextSize(17);
        tvNom.setTextColor(getColor(R.color.text_primary));

        TextView tvCif = new TextView(requireContext());
        tvCif.setText("CIF · " + empresa.cif);
        tvCif.setTextSize(13);
        tvCif.setTextColor(getColor(R.color.text_secondary));
        tvCif.setPadding(0, dp(2), 0, dp(12));


        LinearLayout rowBtns = new LinearLayout(requireContext());
        rowBtns.setOrientation(LinearLayout.HORIZONTAL);

        MaterialButton btnProd = new MaterialButton(requireContext());
        btnProd.setText("Productes");
        btnProd.setAllCaps(false);
        btnProd.setCornerRadius(dp(12));
        btnProd.setBackgroundColor(getColor(R.color.green_dark));
        btnProd.setTextColor(0xFFFFFFFF);

        LinearLayout.LayoutParams lpBtn1 = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        );
        lpBtn1.rightMargin = dp(8);
        btnProd.setLayoutParams(lpBtn1);

        btnProd.setOnClickListener(v -> {
            ProductListFragment f = ProductListFragment.newInstance(empresa.cif, empresa.nom);
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.nav_host_fragment, f)
                    .addToBackStack(null)
                    .commit();
        });

        MaterialButton btnPacks = new MaterialButton(requireContext());
        btnPacks.setText("Packs");
        btnPacks.setAllCaps(false);
        btnPacks.setCornerRadius(dp(12));
        btnPacks.setBackgroundColor(getColor(R.color.green_dark));
        btnPacks.setTextColor(0xFFFFFFFF);

        LinearLayout.LayoutParams lpBtn2 = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        );
        btnPacks.setLayoutParams(lpBtn2);

        btnPacks.setOnClickListener(v -> {
            PackListFragment f = PackListFragment.newInstance(empresa.cif, empresa.nom);
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.nav_host_fragment, f)
                    .addToBackStack(null)
                    .commit();
        });

        rowBtns.addView(btnProd);
        rowBtns.addView(btnPacks);

        content.addView(tvNom);
        content.addView(tvCif);
        content.addView(rowBtns);

        card.addView(content);
        return card;
    }

    private int dp(int v) {
        float d = requireContext().getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }

    private int getColor(int res) {
        return requireContext().getColor(res);
    }
}
