package com.example.altoque;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerApi {


    private static final String HOST = "10.0.2.2";
    private static final int PORT = 5050;


    public static class LoginResult {
        public final boolean ok;
        public final String missatge;
        public final String token;
        public final AuthManager.Role role;

        public LoginResult(boolean ok, String missatge, String token, AuthManager.Role role) {
            this.ok = ok;
            this.missatge = missatge;
            this.token = token;
            this.role = role;
        }
    }

    public static class SimpleResult {
        public final boolean ok;
        public final String missatge;

        public SimpleResult(boolean ok, String missatge) {
            this.ok = ok;
            this.missatge = missatge;
        }
    }

    private static JSONObject sendRequest(JSONObject request) throws Exception {
        Socket socket = null;
        try {
            socket = new Socket(HOST, PORT);

            PrintWriter out = new PrintWriter(
                    new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), "UTF-8"));


            String plain = request.toString();
            String encryptedLine = CryptoAltoque.encryptToBase64(plain);
            out.println(encryptedLine);


            String encryptedResponse = in.readLine();
            if (encryptedResponse == null) return null;


            String responsePlain = CryptoAltoque.decryptFromBase64(encryptedResponse);

            return new JSONObject(responsePlain);

        } finally {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        }
    }

    public static LoginResult login(String usuari, String contrasenya) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "LOGIN");
            req.put("token", JSONObject.NULL);

            JSONArray data = new JSONArray();
            data.put(usuari);
            data.put(contrasenya);
            req.put("data", data);

            JSONObject res = sendRequest(req);
            if (res == null) {
                return new LoginResult(false, "Sense resposta del servidor", null, null);
            }

            int codi = res.optInt("codi", 1);
            String missatge = res.optString("missatge", "Sense missatge");

            if (codi != 0) {
                return new LoginResult(false, missatge, null, null);
            }

            String token = null;
            AuthManager.Role role = null;

            JSONArray dataRes = res.optJSONArray("data");
            if (dataRes != null) {
                if (dataRes.length() >= 1) token = dataRes.optString(0, null);
                if (dataRes.length() >= 2) {
                    String rolSrv = dataRes.optString(1, "");
                    if ("EMPRESA".equalsIgnoreCase(rolSrv)) {
                        role = AuthManager.Role.COMPANY;
                    } else if ("USUARI".equalsIgnoreCase(rolSrv)) {
                        role = AuthManager.Role.CLIENT;
                    }
                }
            }

            return new LoginResult(true, missatge, token, role);

        } catch (Exception e) {
            return new LoginResult(false, "Error: " + e.getMessage(), null, null);
        }
    }

    public static SimpleResult registerUser(
            String nomUsuari,
            String contrasenya,
            String nom,
            String cognoms
    ) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "USUARI_ADD");
            req.put("token", JSONObject.NULL);

            JSONArray data = new JSONArray();
            data.put(nomUsuari);
            data.put(contrasenya);
            data.put(nom);
            data.put(cognoms);
            req.put("data", data);

            JSONObject res = sendRequest(req);
            return parseSimpleResult(res);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static SimpleResult registerCompany(
            String cif,
            String contrasenya,
            String nomEmpresa
    ) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "EMPRESA_ADD");
            req.put("token", JSONObject.NULL);

            JSONArray data = new JSONArray();
            data.put(cif);
            data.put(contrasenya);
            data.put(nomEmpresa);
            req.put("data", data);

            JSONObject res = sendRequest(req);
            return parseSimpleResult(res);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    private static SimpleResult parseSimpleResult(JSONObject res) {
        if (res == null) {
            return new SimpleResult(false, "Sense resposta del servidor");
        }
        int codi = res.optInt("codi", 1);
        String missatge = res.optString("missatge", "Sense missatge");
        return new SimpleResult(codi == 0, missatge);
    }

    public static class EmpresaListResult {
        public final boolean ok;
        public final String missatge;
        public final List<EmpresaInfo> empreses;

        public EmpresaListResult(boolean ok, String missatge, List<EmpresaInfo> empreses) {
            this.ok = ok;
            this.missatge = missatge;
            this.empreses = empreses;
        }
    }

    public static EmpresaListResult empresaList(String token) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "EMPRESA_LIST");
            req.put("token", token);
            req.put("data", new JSONArray());

            JSONObject res = sendRequest(req);
            if (res == null) return new EmpresaListResult(false, "Sense resposta del servidor", new ArrayList<>());

            int codi = res.optInt("codi", 1);
            String missatge = res.optString("missatge", "");

            if (codi != 0) {
                return new EmpresaListResult(false, missatge, new ArrayList<>());
            }

            List<EmpresaInfo> out = new ArrayList<>();

            JSONArray data = res.optJSONArray("data");
            if (data != null) {
                if (data.length() > 0 && data.opt(0) instanceof JSONArray) {
                    JSONArray arr = data.optJSONArray(0);
                    if (arr != null) {
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject obj = arr.optJSONObject(i);
                            if (obj != null) {
                                out.add(new EmpresaInfo(obj.optString("cif"), obj.optString("nom")));
                            }
                        }
                    }
                } else {
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject obj = data.optJSONObject(i);
                        if (obj != null) {
                            out.add(new EmpresaInfo(obj.optString("cif"), obj.optString("nom")));
                        }
                    }
                }
            }

            return new EmpresaListResult(true, missatge, out);

        } catch (Exception e) {
            return new EmpresaListResult(false, "Error: " + e.getMessage(), new ArrayList<>());
        }
    }

    public static SimpleResult producteAdd(String token, String nom, String desc, String preu) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "PRODUCTE_ADD");
            req.put("token", token);

            JSONArray data = new JSONArray();
            data.put(nom);
            data.put(desc);
            data.put(preu);
            req.put("data", data);

            JSONObject res = sendRequest(req);
            return parseSimpleResult(res);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static class Producte {
        public final String id;
        public final String nom;
        public final String descripcio;
        public final double preu;
        public final String cifEmpresa;

        public Producte(String id, String nom, String descripcio, double preu, String cifEmpresa) {
            this.id = id;
            this.nom = nom;
            this.descripcio = descripcio;
            this.preu = preu;
            this.cifEmpresa = cifEmpresa;
        }
    }

    public static class ProductListResult {
        public final boolean ok;
        public final String missatge;
        public final List<Producte> productes;

        public ProductListResult(boolean ok, String missatge, List<Producte> productes) {
            this.ok = ok;
            this.missatge = missatge;
            this.productes = productes;
        }
    }

    public static ProductListResult producteList(String token, String cifOpt) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "PRODUCTE_LIST");
            req.put("token", token);

            JSONArray data = new JSONArray();
            if (cifOpt != null && !cifOpt.trim().isEmpty()) {
                data.put(cifOpt.trim());
            }
            req.put("data", data);

            JSONObject res = sendRequest(req);

            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");

            if (codi != 0) {
                return new ProductListResult(false, missatge, new ArrayList<>());
            }

            JSONArray outer = res.optJSONArray("data");
            if (outer == null) {
                return new ProductListResult(true, missatge, new ArrayList<>());
            }

            JSONArray arr;
            if (outer.length() > 0 && outer.opt(0) instanceof JSONArray) {
                arr = outer.optJSONArray(0);
            } else {
                arr = outer;
            }

            List<Producte> list = new ArrayList<>();
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o == null) continue;

                    String id = o.optString("id", "");
                    String nom = o.optString("nom", "");
                    String des = o.optString("descripcio", "");
                    double preu = o.optDouble("preu", 0.0);
                    String cif = o.optString("cif", null); // al servidor el dto porta "cif"

                    list.add(new Producte(id, nom, des, preu, cif));
                }
            }

            return new ProductListResult(true, missatge, list);

        } catch (Exception e) {
            return new ProductListResult(false, "Error: " + e.getMessage(), new ArrayList<>());
        }
    }

    public static SimpleResult producteDel(String token, String idProducte) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PRODUCTE_DEL");
            req.put("token", token);

            org.json.JSONArray data = new org.json.JSONArray();
            data.put(idProducte);
            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);

            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");

            return new SimpleResult(codi == 0, missatge);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static SimpleResult usuariDel(String token) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "USUARI_DEL");
            req.put("token", token);
            req.put("data", new JSONArray());

            JSONObject res = sendRequest(req);
            return parseSimpleResult(res);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static SimpleResult empresaDel(String token) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "EMPRESA_DEL");
            req.put("token", token);
            req.put("data", new JSONArray());

            JSONObject res = sendRequest(req);
            return parseSimpleResult(res);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static SimpleResult usuariMod(String token, String nomUsuari, String password, String nom, String cognoms) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "USUARI_MOD");
            req.put("token", token);

            JSONObject dto = new JSONObject();
            dto.put("nomusuari", nomUsuari);
            dto.put("contrasenya", password == null ? "" : password);
            dto.put("nom", nom == null ? "" : nom);
            dto.put("cognoms", cognoms == null ? "" : cognoms);

            JSONArray data = new JSONArray();
            data.put(dto);
            req.put("data", data);

            JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");
            return new SimpleResult(codi == 0, missatge);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static SimpleResult empresaMod(String token, String cif, String password, String nomEmpresa) {
        try {
            JSONObject req = new JSONObject();
            req.put("peticio", "EMPRESA_MOD");
            req.put("token", token);

            JSONObject dto = new JSONObject();
            dto.put("cif", cif); // ✅ OBLIGATORI al servidor
            dto.put("contrasenya", password == null ? "" : password);
            dto.put("nom", nomEmpresa == null ? "" : nomEmpresa);

            JSONArray data = new JSONArray();
            data.put(dto);
            req.put("data", data);

            JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");
            return new SimpleResult(codi == 0, missatge);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static class Pack {
        public final String id;
        public final String nom;
        public final String descripcio;
        public final long preu;
        public final int numItems;

        public Pack(String id, String nom, String descripcio, long preu, int numItems) {
            this.id = id;
            this.nom = nom;
            this.descripcio = descripcio;
            this.preu = preu;
            this.numItems = numItems;
        }
    }

    public static class PackListResult {
        public final boolean ok;
        public final String missatge;
        public final java.util.List<Pack> packs;

        public PackListResult(boolean ok, String missatge, java.util.List<Pack> packs) {
            this.ok = ok;
            this.missatge = missatge;
            this.packs = packs;
        }
    }

    public static PackListResult packList(String token, String cifOpt) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PACK_LIST");
            req.put("token", token);

            org.json.JSONArray data = new org.json.JSONArray();
            if (cifOpt != null && !cifOpt.trim().isEmpty()) data.put(cifOpt.trim());
            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);

            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");

            if (codi != 0) return new PackListResult(false, missatge, new java.util.ArrayList<>());

            org.json.JSONArray outer = res.optJSONArray("data");
            if (outer == null) return new PackListResult(true, missatge, new java.util.ArrayList<>());


            org.json.JSONArray arr;
            if (outer.length() > 0 && outer.opt(0) instanceof org.json.JSONArray) arr = outer.optJSONArray(0);
            else arr = outer;

            java.util.List<Pack> list = new java.util.ArrayList<>();
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    org.json.JSONObject o = arr.optJSONObject(i);
                    if (o == null) continue;

                    String id = o.optString("id", o.optString("idPack", ""));
                    String nom = o.optString("nom", "");
                    String des = o.optString("descripcio", "");
                    long preu = o.optLong("preu", 0L);



                    int numItems = 0;
                    org.json.JSONArray items = o.optJSONArray("items");
                    if (items == null) items = o.optJSONArray("productes");
                    if (items != null) numItems = items.length();

                    list.add(new Pack(id, nom, des, preu, numItems));
                }
            }

            return new PackListResult(true, missatge, list);

        } catch (Exception e) {
            return new PackListResult(false, "Error: " + e.getMessage(), new java.util.ArrayList<>());
        }
    }

    public static SimpleResult packAdd(String token, String nom, long preuCents, java.util.List<String> productIds) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PACK_ADD");
            req.put("token", token);

            org.json.JSONObject dto = new org.json.JSONObject();
            dto.put("nom", nom);
            dto.put("preu", preuCents);

            org.json.JSONArray items = new org.json.JSONArray();
            for (String idStr : productIds) {
                long id = Long.parseLong(idStr);

                org.json.JSONObject item = new org.json.JSONObject();
                item.put("producteId", id);
                item.put("quantitat", 1);

                items.put(item);
            }
            dto.put("items", items);

            org.json.JSONArray data = new org.json.JSONArray();
            data.put(dto);
            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");
            return new SimpleResult(codi == 0, missatge);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static class PackDetail {
        public final long id;
        public final String nom;
        public final long preu;
        public final List<String> producteIds;
        public final List<PackItem> items;


        public PackDetail(long id, String nom, long preu,
                          List<String> producteIds,
                          List<PackItem> items) {
            this.id = id;
            this.nom = nom;
            this.preu = preu;
            this.producteIds = producteIds;
            this.items = items;
        }


        public PackDetail(long id, String nom, long preu,
                          List<String> producteIds) {
            this(id, nom, preu, producteIds, new ArrayList<>());
        }
    }


    public static class PackGetResult {
        public final boolean ok;
        public final String missatge;
        public final PackDetail pack;

        public PackGetResult(boolean ok, String missatge, PackDetail pack) {
            this.ok = ok;
            this.missatge = missatge;
            this.pack = pack;
        }
    }

    public static PackGetResult packGet(String token, long packId) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PACK_GET");
            req.put("token", token);

            org.json.JSONArray data = new org.json.JSONArray();
            data.put(String.valueOf(packId));
            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");

            if (codi != 0) return new PackGetResult(false, missatge, null);

            org.json.JSONArray outer = res.optJSONArray("data");
            org.json.JSONObject o = null;


            if (outer != null && outer.length() > 0) {
                Object first = outer.opt(0);
                if (first instanceof org.json.JSONObject) o = (org.json.JSONObject) first;
                else if (first instanceof org.json.JSONArray) o = ((org.json.JSONArray) first).optJSONObject(0);
            }
            if (o == null) return new PackGetResult(true, missatge, null);


            long id = parseLongSafe(o.optString("id", null));
            if (id <= 0) id = o.optLong("id", o.optLong("idPack", packId));

            String nom = o.optString("nom", "");
            long preu = o.optLong("preu", 0L);

            List<String> ids = new ArrayList<>();
            List<PackItem> packItems = new ArrayList<>();

            org.json.JSONArray items = o.optJSONArray("items");
            if (items != null) {
                for (int i = 0; i < items.length(); i++) {
                    org.json.JSONObject it = items.optJSONObject(i);
                    if (it == null) continue;

                    // producteId pot venir com número o string
                    String pid = it.optString("producteId", "");
                    if (pid.isEmpty()) {
                        long pidLong = it.optLong("producteId", -1);
                        if (pidLong > 0) pid = String.valueOf(pidLong);
                    }

                    int q = it.optInt("quantitat", 1);

                    if (!pid.isEmpty()) {
                        ids.add(pid);
                        packItems.add(new PackItem(pid, q));
                    }
                }
            }

            return new PackGetResult(true, missatge, new PackDetail(id, nom, preu, ids, packItems));

        } catch (Exception e) {
            return new PackGetResult(false, "Error: " + e.getMessage(), null);
        }
    }


    private static long parseLongSafe(String s) {
        try { return s == null ? -1 : Long.parseLong(s); }
        catch (Exception e) { return -1; }
    }


    public static PackGetResult packGet(String token, long packId, String cifEmpresaOpt) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PACK_GET");
            req.put("token", token);

            org.json.JSONArray data = new org.json.JSONArray();

            if (cifEmpresaOpt != null && !cifEmpresaOpt.trim().isEmpty()) {

                org.json.JSONObject dto = new org.json.JSONObject();
                dto.put("cif", cifEmpresaOpt);
                dto.put("id", packId);
                data.put(dto);
            } else {

                data.put(packId);
            }

            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");

            if (codi != 0) return new PackGetResult(false, missatge, null);


            org.json.JSONArray d = res.optJSONArray("data");
            if (d == null || d.length() == 0) return new PackGetResult(false, "Resposta buida", null);

            org.json.JSONObject o = d.getJSONObject(0);
            long id = o.optLong("id", -1);
            String nom = o.optString("nom", "");
            long preu = o.optLong("preu", 0);

            java.util.List<String> ids = new java.util.ArrayList<>();
            org.json.JSONArray items = o.optJSONArray("items");
            if (items != null) {
                for (int i = 0; i < items.length(); i++) {
                    org.json.JSONObject it = items.getJSONObject(i);
                    String pid = it.optString("producteId", null);
                    if (pid != null && !pid.isEmpty()) ids.add(pid);
                }
            }

            PackDetail detail = new PackDetail(id, nom, preu, ids);
            return new PackGetResult(true, missatge, detail);

        } catch (Exception e) {
            return new PackGetResult(false, "Error: " + e.getMessage(), null);
        }
    }


    public static SimpleResult packMod(String token, long packId, String nom, long preuCents, List<String> productIds) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PACK_MOD");
            req.put("token", token);

            org.json.JSONObject dto = new org.json.JSONObject();
            dto.put("id", packId);
            dto.put("nom", nom);
            dto.put("preu", preuCents);

            org.json.JSONArray items = new org.json.JSONArray();
            for (String pidStr : productIds) {
                long pid = Long.parseLong(pidStr);
                org.json.JSONObject item = new org.json.JSONObject();
                item.put("producteId", pid);
                item.put("quantitat", 1);
                items.put(item);
            }
            dto.put("items", items);

            org.json.JSONArray data = new org.json.JSONArray();
            data.put(dto);
            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");
            return new SimpleResult(codi == 0, missatge);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static SimpleResult producteMod(String token, long id,  String nomOpt,
                                            String descOpt,  Double preuOpt) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PRODUCTE_MOD");
            req.put("token", token);

            org.json.JSONObject dto = new org.json.JSONObject();
            dto.put("id", id); // obligatori

            if (nomOpt != null) dto.put("nom", nomOpt);
            if (descOpt != null) dto.put("descripcio", descOpt);
            if (preuOpt != null) dto.put("preu", preuOpt); // double (euros)

            org.json.JSONArray data = new org.json.JSONArray();
            data.put(dto);
            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", 1);
            String missatge = res.optString("missatge", "");
            return new SimpleResult(codi == 0, missatge);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }


    public static SimpleResult packDel(String token, long packId) {
        try {
            org.json.JSONObject req = new org.json.JSONObject();
            req.put("peticio", "PACK_DEL");
            req.put("token", token);

            org.json.JSONArray data = new org.json.JSONArray();
            data.put(packId);          // el servidor espera l'id dins data[0]
            req.put("data", data);

            org.json.JSONObject res = sendRequest(req);
            int codi = res.optInt("codi", -1);
            String missatge = res.optString("missatge", "");
            return new SimpleResult(codi == 0, missatge);

        } catch (Exception e) {
            return new SimpleResult(false, "Error: " + e.getMessage());
        }
    }

    public static class PackItem {
        public final String producteId;
        public final int quantitat;
        public PackItem(String producteId, int quantitat) {
            this.producteId = producteId;
            this.quantitat = quantitat;
        }
    }


}
