package com.example.altoque.ui;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.altoque.AuthManager;
import com.example.altoque.R;
import com.example.altoque.ServerApi;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class PackDetailFragment extends Fragment {

    private static final String ARG_CIF = "cif";
    private static final String ARG_EMPRESA_NOM = "nom_empresa";
    private static final String ARG_PACK_ID = "pack_id";
    private static final String ARG_PACK_NOM = "pack_nom";

    private LinearLayout content;
    private ProgressBar progress;

    public PackDetailFragment() {}

    public static PackDetailFragment newInstance(String cif, String empresaNom, String packId, String packNom) {
        PackDetailFragment f = new PackDetailFragment();
        Bundle b = new Bundle();
        b.putString(ARG_CIF, cif);
        b.putString(ARG_EMPRESA_NOM, empresaNom);
        b.putString(ARG_PACK_ID, packId);
        b.putString(ARG_PACK_NOM, packNom);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull android.view.LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        ScrollView scroll = new ScrollView(requireContext());
        scroll.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(requireContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(48), dp(16), dp(16));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);


        MaterialButton back = new MaterialButton(requireContext());
        back.setText("← Tornar");
        back.setAllCaps(false);
        back.setOnClickListener(v -> requireActivity().getOnBackPressedDispatcher().onBackPressed());
        root.addView(back);

        String packNom = getArguments() != null ? getArguments().getString(ARG_PACK_NOM, "Detall pack") : "Detall pack";
        String empresaNom = getArguments() != null ? getArguments().getString(ARG_EMPRESA_NOM, "") : "";

        MaterialTextView title = new MaterialTextView(requireContext());
        title.setText(packNom);
        title.setTextSize(20f);
        title.setTypeface(null, Typeface.BOLD);
        setBottomMargin(title, dp(6));
        root.addView(title);

        if (!empresaNom.isEmpty()) {
            MaterialTextView sub = new MaterialTextView(requireContext());
            sub.setText("Empresa: " + empresaNom);
            sub.setTextSize(14f);
            setBottomMargin(sub, dp(12));
            root.addView(sub);
        } else {
            root.addView(space(dp(8)));
        }

        MaterialCardView card = new MaterialCardView(requireContext());
        card.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        card.setRadius(dp(18));
        card.setCardElevation(dp(2));
        card.setUseCompatPadding(true);

        content = new LinearLayout(requireContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(16));

        progress = new ProgressBar(requireContext());
        progress.setVisibility(View.VISIBLE);
        content.addView(progress);

        card.addView(content);
        root.addView(card);

        return scroll;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadDetails();
    }

    private void loadDetails() {
        String cif = getArguments() != null ? getArguments().getString(ARG_CIF, null) : null;
        String packIdStr = getArguments() != null ? getArguments().getString(ARG_PACK_ID, null) : null;

        if (cif == null || cif.trim().isEmpty() || packIdStr == null || packIdStr.trim().isEmpty()) {
            Toast.makeText(requireContext(), "Error: dades del pack no vàlides", Toast.LENGTH_LONG).show();
            return;
        }

        final long packId;
        try {
            packId = Long.parseLong(packIdStr);
        } catch (Exception e) {
            Toast.makeText(requireContext(), "Error: id pack invàlid", Toast.LENGTH_LONG).show();
            return;
        }

        String token = new AuthManager(requireContext()).getToken();
        progress.setVisibility(View.VISIBLE);

        new Thread(() -> {
            ServerApi.PackGetResult packRes = ServerApi.packGet(token, packId, cif);
            ServerApi.ProductListResult prodRes = ServerApi.producteList(token, cif);

            requireActivity().runOnUiThread(() -> {
                content.removeAllViews();

                if (!packRes.ok || packRes.pack == null) {
                    content.addView(txt("Error: " + packRes.missatge, 14));
                    return;
                }
                if (!prodRes.ok) {
                    content.addView(txt("Error carregant productes: " + prodRes.missatge, 14));
                    return;
                }


                double euros = packRes.pack.preu / 100.0;
                content.addView(txt(String.format(Locale.getDefault(), "Preu: %.2f €", euros), 16));
                content.addView(space(dp(12)));

                List<String> packIds = packRes.pack.producteIds;
                if (packIds == null || packIds.isEmpty()) {
                    content.addView(txt("Aquest pack no té productes.", 14));
                    return;
                }


                HashMap<String, ServerApi.Producte> map = new HashMap<>();
                if (prodRes.productes != null) {
                    for (ServerApi.Producte p : prodRes.productes) map.put(p.id, p);
                }

                Set<String> ids = new HashSet<>(packIds);

                content.addView(txtBold("Productes inclosos:", 16));
                content.addView(space(dp(8)));

                for (String pid : ids) {
                    ServerApi.Producte p = map.get(pid);
                    if (p == null) {
                        content.addView(txt("• Producte #" + pid, 14));
                    } else {
                        content.addView(txt("• " + p.nom + " · " + p.preu + " €", 14));
                    }
                }
            });
        }).start();
    }


    private MaterialTextView txt(String s, int size) {
        MaterialTextView t = new MaterialTextView(requireContext());
        t.setText(s);
        t.setTextSize(size);
        return t;
    }

    private MaterialTextView txtBold(String s, int size) {
        MaterialTextView t = txt(s, size);
        t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private View space(int h) {
        View v = new View(requireContext());
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, h
        ));
        return v;
    }

    private void setBottomMargin(View v, int margin) {
        ViewGroup.LayoutParams base = v.getLayoutParams();
        LinearLayout.LayoutParams lp;
        if (base instanceof LinearLayout.LayoutParams) lp = (LinearLayout.LayoutParams) base;
        else lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = margin;
        v.setLayoutParams(lp);
    }

    private int dp(int v) {
        float d = requireContext().getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }
}
