package com.example.altoque;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class RegisterCompanyActivity extends AppCompatActivity {

    private TextInputEditText etCompanyName, etCif, etPassCompany;
    private Button btnCreateCompany;
    private TextView tvBackToLoginCompany;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_company);

        etCompanyName = findViewById(R.id.etCompanyName);
        etCif = findViewById(R.id.etCif);
        etPassCompany = findViewById(R.id.etPassCompany);
        btnCreateCompany = findViewById(R.id.btnCreateCompany);
        tvBackToLoginCompany = findViewById(R.id.tvBackToLoginCompany);

        btnCreateCompany.setOnClickListener(v -> validateAndCreate());
        tvBackToLoginCompany.setOnClickListener(v -> finish());
    }

    private void validateAndCreate() {
        clearErrors();

        String companyName = safeText(etCompanyName);
        String cif = safeText(etCif);
        String pass = safeText(etPassCompany);

        boolean hasError = false;

        if (TextUtils.isEmpty(companyName)) {
            etCompanyName.setError("El nom de l'empresa és obligatori");
            hasError = true;
        }
        if (TextUtils.isEmpty(cif)) {
            etCif.setError("El CIF/NIF és obligatori");
            hasError = true;
        }
        if (TextUtils.isEmpty(pass)) {
            etPassCompany.setError("La contrasenya és obligatòria");
            hasError = true;
        }

        if (hasError) {
            Toast.makeText(this, "Revisa els camps marcats", Toast.LENGTH_SHORT).show();
            return;
        }


        final String finalCif = cif;
        final String finalPass = pass;
        final String finalCompanyName = companyName;

        setEnabled(false);
        btnCreateCompany.setText("Creant...");

        new Thread(() -> {
            ServerApi.SimpleResult res = ServerApi.registerCompany(finalCif, finalPass, finalCompanyName);

            runOnUiThread(() -> {
                setEnabled(true);
                btnCreateCompany.setText("Crear empresa");

                Toast.makeText(this, res.missatge, Toast.LENGTH_LONG).show();
                if (res.ok) finish();
            });
        }).start();
    }

    private void setEnabled(boolean enabled) {
        etCompanyName.setEnabled(enabled);
        etCif.setEnabled(enabled);
        etPassCompany.setEnabled(enabled);
        btnCreateCompany.setEnabled(enabled);
        tvBackToLoginCompany.setEnabled(enabled);
    }

    private void clearErrors() {
        etCompanyName.setError(null);
        etCif.setError(null);
        etPassCompany.setError(null);
    }

    private String safeText(TextInputEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString().trim();
    }
}
