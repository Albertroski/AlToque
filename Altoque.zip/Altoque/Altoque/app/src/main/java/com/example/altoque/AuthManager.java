package com.example.altoque;

import android.content.Context;
import android.content.SharedPreferences;

public class AuthManager {
    private static final String PREF = "altoque_auth";
    private static final String KEY_TOKEN = "auth_token";
    private static final String KEY_ROLE = "auth_role";
    private static final String KEY_ID = "auth_id"; // ✅ email (usuari) o CIF (empresa)
    private static final String KEY_NAME = "auth_name"; // ✅ nom visible (local)


    public enum Role { CLIENT, COMPANY }

    private final SharedPreferences prefs;

    public AuthManager(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void saveAuth(String token, String role) {

        prefs.edit()
                .putString(KEY_TOKEN, token)
                .putString(KEY_ROLE, role)
                .apply();
    }

    public void saveAuth(String token, String role, String identifier) {
        prefs.edit()
                .putString(KEY_TOKEN, token)
                .putString(KEY_ROLE, role)
                .putString(KEY_ID, identifier)
                .apply();
    }

    public String getToken() {
        return prefs.getString(KEY_TOKEN, null);
    }

    public Role getRole() {
        String r = prefs.getString(KEY_ROLE, null);
        if (r == null) return null;
        try { return Role.valueOf(r); } catch (IllegalArgumentException e) { return null; }
    }

    public String getIdentifier() {
        return prefs.getString(KEY_ID, null);
    }

    public void setDisplayName(String name) {
        prefs.edit().putString(KEY_NAME, name).apply();
    }

    public String getDisplayName() {
        return prefs.getString(KEY_NAME, null);
    }


    public boolean isAuthenticated() {
        return getToken() != null;
    }

    public void clear() {
        prefs.edit().clear().apply();
    }
}
