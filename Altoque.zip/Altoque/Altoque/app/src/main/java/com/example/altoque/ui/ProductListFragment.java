package com.example.altoque.ui;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.altoque.AuthManager;
import com.example.altoque.ServerApi;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.List;

public class ProductListFragment extends Fragment {

    private static final String ARG_CIF = "cif";
    private static final String ARG_NOM = "nom";

    private LinearLayout listContainer;
    private ProgressBar progress;

    public ProductListFragment() {}

    public static ProductListFragment newInstance(String cif, String nomEmpresa) {
        ProductListFragment f = new ProductListFragment();
        Bundle b = new Bundle();
        b.putString(ARG_CIF, cif);
        b.putString(ARG_NOM, nomEmpresa);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull android.view.LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {


        ScrollView scroll = new ScrollView(requireContext());
        scroll.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(requireContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(48), dp(16), dp(16)); // evita status bar
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        scroll.addView(root);


        MaterialButton back = new MaterialButton(requireContext());
        back.setText("← Tornar");
        back.setAllCaps(false);
        back.setOnClickListener(v -> requireActivity().getOnBackPressedDispatcher().onBackPressed());
        root.addView(back);


        String nom = getArguments() != null ? getArguments().getString(ARG_NOM, "") : "";
        MaterialTextView title = new MaterialTextView(requireContext());
        title.setText(nom.isEmpty() ? "Productes" : "Productes de " + nom);
        title.setTextSize(18f);
        title.setTypeface(null, Typeface.BOLD);
        setBottomMargin(title, dp(10));
        root.addView(title);


        progress = new ProgressBar(requireContext());
        progress.setVisibility(View.GONE);
        setBottomMargin(progress, dp(10));
        root.addView(progress);


        listContainer = new LinearLayout(requireContext());
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        root.addView(listContainer);

        return scroll;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String cif = getArguments() != null ? getArguments().getString(ARG_CIF, null) : null;
        if (cif == null || cif.trim().isEmpty()) {
            Toast.makeText(requireContext(), "Error: CIF no vàlid", Toast.LENGTH_LONG).show();
            return;
        }

        loadProducts(cif);
    }

    private void loadProducts(String cif) {
        listContainer.removeAllViews();
        progress.setVisibility(View.VISIBLE);

        String token = new AuthManager(requireContext()).getToken();

        new Thread(() -> {
            ServerApi.ProductListResult res = ServerApi.producteList(token, cif);

            requireActivity().runOnUiThread(() -> {
                progress.setVisibility(View.GONE);

                if (!res.ok) {
                    Toast.makeText(requireContext(), res.missatge, Toast.LENGTH_LONG).show();
                    return;
                }

                List<ServerApi.Producte> list = res.productes;

                if (list == null || list.isEmpty()) {
                    MaterialTextView empty = new MaterialTextView(requireContext());
                    empty.setText("Aquesta empresa encara no té productes.");
                    listContainer.addView(empty);
                    return;
                }

                for (ServerApi.Producte p : list) {
                    listContainer.addView(makeProductCard(p));
                }
            });
        }).start();
    }

    private View makeProductCard(ServerApi.Producte p) {
        MaterialCardView card = new MaterialCardView(requireContext());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        card.setRadius(dp(16));
        card.setCardElevation(dp(1));
        card.setUseCompatPadding(true);

        LinearLayout content = new LinearLayout(requireContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(14));

        MaterialTextView tvNom = new MaterialTextView(requireContext());
        tvNom.setText(p.nom);
        tvNom.setTextSize(16f);
        tvNom.setTypeface(null, Typeface.BOLD);

        MaterialTextView tvDesc = new MaterialTextView(requireContext());
        tvDesc.setText(p.descripcio);
        tvDesc.setTextSize(14f);

        MaterialTextView tvPreu = new MaterialTextView(requireContext());
        tvPreu.setText("Preu: " + p.preu + " €");
        tvPreu.setTextSize(14f);

        content.addView(tvNom);
        content.addView(space(dp(6)));
        content.addView(tvDesc);
        content.addView(space(dp(8)));
        content.addView(tvPreu);

        card.addView(content);
        return card;
    }

    private View space(int h) {
        View v = new View(requireContext());
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, h
        ));
        return v;
    }

    private void setBottomMargin(View v, int margin) {
        ViewGroup.LayoutParams base = v.getLayoutParams();
        LinearLayout.LayoutParams lp;
        if (base instanceof LinearLayout.LayoutParams) lp = (LinearLayout.LayoutParams) base;
        else lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = margin;
        v.setLayoutParams(lp);
    }

    private int dp(int v) {
        float d = requireContext().getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }
}
