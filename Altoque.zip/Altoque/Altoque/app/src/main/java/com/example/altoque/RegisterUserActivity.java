package com.example.altoque;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class RegisterUserActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPassword;
    private Button btnCreateAccount;
    private TextView tvBackToLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        tvBackToLogin = findViewById(R.id.tvBackToLogin);

        btnCreateAccount.setOnClickListener(v -> validateAndCreate());
        tvBackToLogin.setOnClickListener(v -> finish());
    }

    private void validateAndCreate() {
        clearErrors();

        String fullName = safeText(etName);
        String email = safeText(etEmail);
        String pass = safeText(etPassword);

        boolean hasError = false;

        if (TextUtils.isEmpty(fullName)) { etName.setError("El nom és obligatori"); hasError = true; }
        if (TextUtils.isEmpty(email))    { etEmail.setError("L'email és obligatori"); hasError = true; }
        if (TextUtils.isEmpty(pass))     { etPassword.setError("La contrasenya és obligatòria"); hasError = true; }

        if (!hasError && !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Format d'email no vàlid");
            hasError = true;
        }

        if (hasError) {
            Toast.makeText(this, "Revisa els camps marcats", Toast.LENGTH_SHORT).show();
            return;
        }


        String nomUsuari = email; // fem servir email com a nom d'usuari
        String nom = fullName;
        String cognoms = "";


        String[] parts = fullName.trim().split("\\s+");
        if (parts.length >= 2) {
            nom = parts[0];
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i < parts.length; i++) {
                if (i > 1) sb.append(" ");
                sb.append(parts[i]);
            }
            cognoms = sb.toString();
        }


        final String finalNomUsuari = nomUsuari;
        final String finalPass = pass;
        final String finalNom = nom;
        final String finalCognoms = cognoms;

        setEnabled(false);
        btnCreateAccount.setText("Creant...");

        new Thread(() -> {
            ServerApi.SimpleResult res =
                    ServerApi.registerUser(finalNomUsuari, finalPass, finalNom, finalCognoms);

            runOnUiThread(() -> {
                setEnabled(true);
                btnCreateAccount.setText("Crear compte");

                Toast.makeText(this, res.missatge, Toast.LENGTH_LONG).show();
                if (res.ok) finish();
            });
        }).start();

    }

    private void setEnabled(boolean enabled) {
        etName.setEnabled(enabled);
        etEmail.setEnabled(enabled);
        etPassword.setEnabled(enabled);
        btnCreateAccount.setEnabled(enabled);
        tvBackToLogin.setEnabled(enabled);
    }

    private void clearErrors() {
        etName.setError(null);
        etEmail.setError(null);
        etPassword.setError(null);
    }

    private String safeText(TextInputEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString().trim();
    }
}
