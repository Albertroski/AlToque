package com.example.altoque;

public class EmpresaInfo {
    public final String cif;
    public final String nom;

    public EmpresaInfo(String cif, String nom) {
        this.cif = cif;
        this.nom = nom;
    }

    @Override
    public String toString() {
        return nom + " (" + cif + ")";
    }
}
