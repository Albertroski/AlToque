package com.example.altoque.ui;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.altoque.AuthManager;
import com.example.altoque.R;
import com.example.altoque.ServerApi;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.List;
import java.util.Locale;

public class PackListFragment extends Fragment {

    private static final String ARG_CIF = "cif";
    private static final String ARG_NOM = "nom";

    private LinearLayout listContainer;
    private ProgressBar progress;

    public PackListFragment() {}

    public static PackListFragment newInstance(String cif, String nomEmpresa) {
        PackListFragment f = new PackListFragment();
        Bundle b = new Bundle();
        b.putString(ARG_CIF, cif);
        b.putString(ARG_NOM, nomEmpresa);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull android.view.LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        ScrollView scroll = new ScrollView(requireContext());
        scroll.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(requireContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(48), dp(16), dp(16));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        MaterialButton back = new MaterialButton(requireContext());
        back.setText("← Tornar");
        back.setAllCaps(false);
        back.setOnClickListener(v -> requireActivity().getOnBackPressedDispatcher().onBackPressed());
        root.addView(back);

        String nom = getArguments() != null ? getArguments().getString(ARG_NOM, "") : "";
        MaterialTextView title = new MaterialTextView(requireContext());
        title.setText(nom.isEmpty() ? "Packs" : "Packs de " + nom);
        title.setTextSize(18f);
        title.setTypeface(null, Typeface.BOLD);
        setBottomMargin(title, dp(10));
        root.addView(title);

        progress = new ProgressBar(requireContext());
        progress.setVisibility(View.GONE);
        setBottomMargin(progress, dp(10));
        root.addView(progress);

        listContainer = new LinearLayout(requireContext());
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        root.addView(listContainer);

        return scroll;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String cif = getArguments() != null ? getArguments().getString(ARG_CIF, null) : null;
        if (cif == null || cif.trim().isEmpty()) {
            Toast.makeText(requireContext(), "Error: CIF no vàlid", Toast.LENGTH_LONG).show();
            return;
        }

        loadPacks(cif);
    }

    private void loadPacks(String cif) {
        listContainer.removeAllViews();
        progress.setVisibility(View.VISIBLE);

        String token = new AuthManager(requireContext()).getToken();

        new Thread(() -> {
            ServerApi.PackListResult res = ServerApi.packList(token, cif);

            requireActivity().runOnUiThread(() -> {
                progress.setVisibility(View.GONE);

                if (!res.ok) {
                    Toast.makeText(requireContext(), res.missatge, Toast.LENGTH_LONG).show();
                    return;
                }

                List<ServerApi.Pack> packs = res.packs;

                if (packs == null || packs.isEmpty()) {
                    MaterialTextView empty = new MaterialTextView(requireContext());
                    empty.setText("Aquesta empresa encara no té packs.");
                    listContainer.addView(empty);
                    return;
                }

                for (ServerApi.Pack p : packs) {
                    listContainer.addView(makePackCard(p));
                }
            });
        }).start();
    }

    private View makePackCard(ServerApi.Pack p) {
        MaterialCardView card = new MaterialCardView(requireContext());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        card.setRadius(dp(16));
        card.setCardElevation(dp(1));
        card.setUseCompatPadding(true);

        card.setClickable(true);
        card.setFocusable(true);

        LinearLayout content = new LinearLayout(requireContext());
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(14));

        MaterialTextView tvNom = new MaterialTextView(requireContext());
        tvNom.setText(p.nom);
        tvNom.setTextSize(16f);
        tvNom.setTypeface(null, Typeface.BOLD);

        MaterialTextView tvDesc = new MaterialTextView(requireContext());
        tvDesc.setText(p.descripcio);
        tvDesc.setTextSize(14f);

        MaterialTextView tvInfo = new MaterialTextView(requireContext());
        String itemsTxt = (p.numItems > 0) ? (" · " + p.numItems + " productes") : "";
        double euros = p.preu / 100.0; // ✅ cents -> euros
        tvInfo.setText(String.format(Locale.getDefault(), "Preu: %.2f €%s", euros, itemsTxt));
        tvInfo.setTextSize(14f);

        content.addView(tvNom);
        content.addView(space(dp(6)));
        content.addView(tvDesc);
        content.addView(space(dp(8)));
        content.addView(tvInfo);

        card.addView(content);


        card.setOnClickListener(v -> showBasicPackDialog(p));

        return card;
    }

    private void showBasicPackDialog(ServerApi.Pack p) {
        double euros = p.preu / 100.0; // cents -> euros

        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(10), dp(16), dp(6));

        MaterialTextView tNom = new MaterialTextView(requireContext());
        tNom.setText(p.nom);
        tNom.setTextSize(18f);
        tNom.setTypeface(null, Typeface.BOLD);

        MaterialTextView tDesc = new MaterialTextView(requireContext());
        tDesc.setText(p.descripcio == null ? "" : p.descripcio);
        tDesc.setTextSize(14f);
        tDesc.setPadding(0, dp(6), 0, dp(10));

        MaterialTextView tInfo = new MaterialTextView(requireContext());
        String itemsTxt = (p.numItems > 0) ? (p.numItems + " productes") : "Productes: ?";
        tInfo.setText(String.format(Locale.getDefault(), "Preu: %.2f € · %s", euros, itemsTxt));
        tInfo.setTextSize(14f);

        MaterialTextView tNote = new MaterialTextView(requireContext());
        tNote.setText("Nota: El servidor requereix sessió d’empresa per veure els productes inclosos (PACK_GET).");
        tNote.setTextSize(13f);
        tNote.setPadding(0, dp(12), 0, 0);

        box.addView(tNom);
        if (p.descripcio != null && !p.descripcio.trim().isEmpty()) box.addView(tDesc);
        box.addView(tInfo);
        box.addView(tNote);

        new com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
                .setTitle("Detall del pack")
                .setView(box)
                .setPositiveButton("Tancar", null)
                .show();
    }


    private void openPackDetail(ServerApi.Pack p) {
        String cif = getArguments() != null ? getArguments().getString(ARG_CIF, null) : null;
        String empresaNom = getArguments() != null ? getArguments().getString(ARG_NOM, "") : "";

        if (cif == null || cif.trim().isEmpty()) {
            Toast.makeText(requireContext(), "Error: CIF no vàlid", Toast.LENGTH_LONG).show();
            return;
        }


        PackDetailFragment f = PackDetailFragment.newInstance(cif, empresaNom, p.id, p.nom);

        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.nav_host_fragment, f)
                .addToBackStack(null)
                .commit();
    }

    private View space(int h) {
        View v = new View(requireContext());
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, h
        ));
        return v;
    }

    private void setBottomMargin(View v, int margin) {
        ViewGroup.LayoutParams base = v.getLayoutParams();
        LinearLayout.LayoutParams lp;
        if (base instanceof LinearLayout.LayoutParams) lp = (LinearLayout.LayoutParams) base;
        else lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = margin;
        v.setLayoutParams(lp);
    }

    private int dp(int v) {
        float d = requireContext().getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }
}
